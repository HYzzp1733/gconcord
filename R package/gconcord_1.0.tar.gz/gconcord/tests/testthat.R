library(testthat)
library(gconcord)

test_check("gconcord")
