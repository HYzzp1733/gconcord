#' Daily arithmatic returns of 30 component stocks in DJIA index
#' from 1990/01/03 to 2018/02/28
#'
#' A 30-dimensional time series data frame containing
#' daily returns of 30 component stock in DJIA index
#' with 7095 observations and 30 columns.
#'
#' @format A data frame with 7095 rows and 30 columns:
#' \describe{
#'   \item{AAPL}{arithmatic return}
#'   \item{AXP }{arithmatic return}
#'   \item{ BA }{arithmatic return}
#'   \item{CAT }{arithmatic return}
#'   \item{CSCO}{arithmatic return}
#'   \item{CVX }{arithmatic return}
#'   \item{DIS }{arithmatic return}
#'   \item{DWDP}{arithmatic return}
#'   \item{ GE }{arithmatic return}
#'   \item{ GS }{arithmatic return}
#'   \item{ HD }{arithmatic return}
#'   \item{IBM }{arithmatic return}
#'   \item{INTC}{arithmatic return}
#'   \item{JNJ }{arithmatic return}
#'   \item{JPM }{arithmatic return}
#'   \item{ KO }{arithmatic return}
#'   \item{MCD }{arithmatic return}
#'   \item{MMM }{arithmatic return}
#'   \item{MRK }{arithmatic return}
#'   \item{MSFT}{arithmatic return}
#'   \item{NKE }{arithmatic return}
#'   \item{PFE }{arithmatic return}
#'   \item{ PG }{arithmatic return}
#'   \item{TRV }{arithmatic return}
#'   \item{UNH }{arithmatic return}
#'   \item{UTX }{arithmatic return}
#'   \item{ V  }{arithmatic return}
#'   \item{ VZ }{arithmatic return}
#'   \item{WTM }{arithmatic return}
#'   \item{XOM }{arithmatic return}
#' }
#' @source \URL{https://finance.yahoo.com/}
"return"

#' Daily DJIA index price from 1990/01/02 to 2018/02/28
#'
#' A series data frame containing daily DJIA index
#' with 7096 observations.
#'
#' @format A data frame with 7096 rows and 30 columns:
#' \describe{
#'   \item{Index}{daily index price}
#' }
#' @source \URL{https://finance.yahoo.com/}
"DJIndex"
